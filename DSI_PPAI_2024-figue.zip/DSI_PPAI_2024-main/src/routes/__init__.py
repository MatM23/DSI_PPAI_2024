# Permite que la carpeta routes sea reconocida como un paquete
# e importarlo como un paquete directamente en el app.py