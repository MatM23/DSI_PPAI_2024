from models import Bodega
from datetime import datetime
from database import db_sqlite

db = db_sqlite()
cursor = db.get_cursor()

class Gestor:



    bodegas = []  # Atributo de clase para almacenar todas las bodegas

    @classmethod 
    def agregarBodega(cls, bodega):
        if not isinstance(bodega, Bodega):
            raise TypeError("Debe ser una instancia de la clase Bodega")
        cls.bodegas.append(bodega)

    def getFechaActual():
        fechaActual = datetime.now
        return fechaActual

    @classmethod
    def buscarBodegas(self):
        bodegasTodas = cursor.execute("SELECT * FROM Bodega")
        bodegasActualizar = []
        fechaActual = self.getFechaActual()
        for bodega in bodegasTodas:
            if bodega.esParaActualizar(fechaActual):
                bodegasActualizar.append(bodega.getNombre())

        return bodegasActualizar
    

    def definirVinosAActualizar(self, nombreBodega, vinos):
        bodega = cursor.execute("SELECT * FROM Bodega WHERE nombre = ?", (nombreBodega,))
        vinosActualizar = []
        for vino in vinos:
            if bodega.tieneVino(nombreBodega):
                vinosActualizar.append(vino)
        return vinosActualizar
    
    # funcion para obtener actualizaciones de bodega usando la base de datos
    def obtenerActualizacionesBodega(self, nombreBodega):
        bodega = cursor.execute("SELECT * FROM Bodega WHERE nombre = ?", (nombreBodega,))
        return bodega.getVinos() #tenemos q definir que vinos y de donde vienen 