# Para correr el proyecto e instalar dependencias ejecutar
# pip install -r requirements.text